﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BuildingGen
{
    public partial class DocPropety : Form
    {
        private GWorkspace workspace;
        public DocPropety(GWorkspace workspace)
        {
            InitializeComponent();
            this.workspace = workspace;
        }
    }
}
